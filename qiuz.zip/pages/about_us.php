<!DOCTYPE html>
<html>
<head>

    <link rel='stylesheet' type='text/css' href='../css/about_us.css'>

</head>
<body>
    <div class="team-section">
        <h1>Our Team </h1>
        <span class="border"></span>

        <div class="ps">
            <a href="#p1"><img src="../images/kkr.jpeg" alt=""></a>
            <a href="#p2"><img src="../images/hem.jpeg" alt=""></a>
            <a href="#p3"><img src="../images/sst.jpg" alt=""></a>
            <a href="#p4"><img src="../images/aa.jpeg" alt=""></a>
        </div>

        <div class="section" id="p1">
            <span class="name">Krishna Kant Rawat</span>
            <span class="border"></span>
            <p>Roll no: 16017I04032</p>
        </div>

        <div class="section" id="p2">
            <span class="name">Hemant Rajpoot</span>
            <span class="border"></span>
            <p>Roll no: 16017I04025</p>
        </div>

        <div class="section" id="p3">
            <span class="name">Satish Ahirwar</span>
            <span class="border"></span>
            <p>Roll no: 16017I04048</p>
        </div>

        <div class="section" id="p4">
            <span class="name">Asat Khan</span>
            <span class="border"></span>
            <p>Roll no: 16017I04012</p>
        </div>
    </div>
</body>
</html>