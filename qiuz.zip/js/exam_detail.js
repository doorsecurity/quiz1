function viewPasscode(id){
    window.open("passcode_exam.php?pid="+id,"_self");
}