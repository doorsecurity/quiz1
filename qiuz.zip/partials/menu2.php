<div>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand text-warning" id="hom" href="homepage_student.php">HOME</a>
    <ul class="navbar-nav">
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-warning" href="#" id="navbardrop" data-toggle="dropdown">
          Profile
        </a>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="student_profile.php">View Profile</a>
          <a class="dropdown-item" href="student_profile_update.php">Update Profile</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-warning" href="view_exam.php" id="navbardrop">
          Exam
        </a>
        
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-warning" href="view_result.php" id="navbardrop">
          Result
        </a>
      </li>
      <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle text-warning" href="about_us.php" id="navbardrop">
          About Us
        </a>
      </li>
    </ul>
  </nav>
</div>
  